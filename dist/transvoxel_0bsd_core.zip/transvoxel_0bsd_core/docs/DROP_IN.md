# Drop-in use

Use the small release zip:

```text
dist/transvoxel_0bsd_core.zip
```

Copy these files into your project:

```text
include/transvoxel.h
src/transvoxel.c
generated/transvoxel_tables.h
```

Compile `src/transvoxel.c` with your project and include both directories:

```sh
-Iinclude -Igenerated
```

## Build examples

Zig:

```sh
zig cc -std=c99 -Iinclude -Igenerated src/transvoxel.c examples/c_minimal/main.c -o c_minimal
```

Generic C compiler:

```sh
cc -std=c99 -Iinclude -Igenerated src/transvoxel.c examples/c_minimal/main.c -o c_minimal
```

Tiny OBJ terrain example:

```sh
zig cc -std=c99 -Iinclude -Igenerated src/transvoxel.c examples/c_terrain_export/main.c -o terrain_export
./terrain_export
```

It writes:

```text
terrain_export.obj
```

## Mental model

The core is deliberately small:

```text
sample scalar values at known local sample positions
compute a case index
use generated tables to create vertices and triangles
append those triangles to your engine mesh
```

You control:

```text
chunk storage
world streaming
SDF/density sampling
vertex deduplication
normals/tangents/materials
GPU upload
collision generation
LOD policy
```

The core only returns mesh triangles for one cell at a time.

## Regular cell

```c
float samples[TV_REGULAR_SAMPLE_COUNT];
for (int i = 0; i < TV_REGULAR_SAMPLE_COUNT; ++i) {
    TvVec3 p = tv_regular_sample_position(i);
    samples[i] = sample_density(p);
}

TvVec3 vertices[TV_REGULAR_MAX_VERTICES];
TvTriangle triangles[TV_REGULAR_MAX_TRIANGLES];

TvBuildInfo info = tv_build_regular_cell(
    samples,
    0.0f,
    tv_vec3(0, 0, 0),
    tv_vec3(1, 1, 1),
    vertices,
    TV_REGULAR_MAX_VERTICES,
    triangles,
    TV_REGULAR_MAX_TRIANGLES);
```

## Transition cell

```c
float samples[TV_TRANSITION_SAMPLE_COUNT];
for (int i = 0; i < TV_TRANSITION_SAMPLE_COUNT; ++i) {
    TvVec3 p = tv_transition_sample_position(i);
    samples[i] = sample_density(p);
}

tv_transition_fill_derived_samples(samples);

TvBuildInfo info = tv_build_transition_cell(
    samples,
    0.0f,
    tv_vec3(0, 0, 0),
    tv_vec3(1, 1, 1),
    vertices,
    TV_TRANSITION_MAX_VERTICES,
    triangles,
    TV_TRANSITION_MAX_TRIANGLES);
```

`tv_transition_fill_derived_samples()` matches the conservative transition boundary contract used by the proof suite. If your engine has true coarse samples, you can provide all 14 transition samples yourself.

## Error handling

Every builder returns `TvBuildInfo`:

```c
if (info.result != TV_OK) {
    /* handle TV_ERROR_NULL, TV_ERROR_SMALL_VERTEX_BUFFER, etc. */
}
```

The maximum buffer sizes are fixed constants:

```text
TV_REGULAR_MAX_VERTICES
TV_REGULAR_MAX_TRIANGLES
TV_TRANSITION_MAX_VERTICES
TV_TRANSITION_MAX_TRIANGLES
```

## What not to expect

This core does not automatically provide:

```text
chunk manager
materials
normals
collision
threading
GPU compute
Godot integration
full gameplay terrain system
```

It is meant to be the small table-driven meshing core that those systems call.
